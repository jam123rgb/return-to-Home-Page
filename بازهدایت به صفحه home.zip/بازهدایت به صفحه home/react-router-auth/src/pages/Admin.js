

import React from "react";
 

function Admin(props) {

  return <div>Admin Page</div>;
}
 

export default Admin;
