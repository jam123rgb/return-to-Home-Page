

import React from "react";
 

function Home(props) {

  return <div>Home Page</div>;
}
 

export default Home;
